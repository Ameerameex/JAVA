package com.example.ui;

public class EmployeeInputUtil {

}
