//package com.example.ui;
//
//import java.util.Calendar;
//import java.util.Date;
//
//public class Application {
//
//	public static void main(String[] args) {
//		int choice;
//		do{
//		MenuHandler handler=new MenuHandler();
//		
//		handler.displayMenu();
//		choice=handler.getChoice();
//	handler.dispatchChoice(choice);
//	}while(choice!=6);
//
//}
//}