package com.example.ui;

public interface Alignments {

	public static final int LEFT=1;
	public static final int RIGHT=2;

	

}
