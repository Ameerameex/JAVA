package com.example.db;

import java.util.List;

import com.example.business.Employee;

public interface EmployeeQueries {

	String SELECT_ALL = "select * from employee";


}
