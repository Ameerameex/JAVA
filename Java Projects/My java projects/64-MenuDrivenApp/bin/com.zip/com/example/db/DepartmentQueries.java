package com.example.db;

public interface DepartmentQueries {

	String SELECT_ALL = "select * from Employee";

}
